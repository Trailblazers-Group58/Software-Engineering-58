// Order data and state management
const orderData = {
  items: [
    {
      id: "handbag",
      name: "Ladies Leather Hand Bag",
      size: "One size",
      price: 80,
      originalPrice: 160,
      quantity: 1,
      image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=80&h=80&fit=crop",
      alt: "Ladies gray leather handbag",
    },
    {
      id: "shirt",
      name: "Short Sleeve",
      size: "One size",
      price: 169.99,
      originalPrice: 190.99,
      quantity: 1,
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=80&h=80&fit=crop",
      alt: "Black and white striped short sleeve shirt",
    },
  ],
  deliveryFee: {
    standard: 5.0,
    express: 30.0,
  },
  selectedDelivery: "standard",
}

// Utility Functions
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

function announceToScreenReader(message) {
  const announcement = document.getElementById("announcements")
  if (announcement) {
    announcement.textContent = message
    setTimeout(() => {
      announcement.textContent = ""
    }, 1000)
  }
}

function handleError(error, context) {
  console.error(`Error in ${context}:`, error)
  announceToScreenReader("An error occurred. Please try again.")
}

function formatPrice(price) {
  return `GHC${price.toFixed(2)}`
}

// Form Validation
function validateField(field) {
  const value = field.value.trim()
  const fieldName = field.name
  const errorElement = document.getElementById(`${field.id}-error`)

  let isValid = true
  let errorMessage = ""

  // Required field validation
  if (field.hasAttribute("required") && !value) {
    isValid = false
    errorMessage = `${fieldName.replace(/([A-Z])/g, " $1").toLowerCase()} is required`
  }

  // Specific field validations
  switch (fieldName) {
    case "firstName":
    case "lastName":
      if (value && value.length < 2) {
        isValid = false
        errorMessage = "Name must be at least 2 characters long"
      }
      break

    case "phoneNumber":
    case "paymentNumber":
      if (value && !/^\d{9}$/.test(value)) {
        isValid = false
        errorMessage = "Please enter a valid 9-digit phone number"
      }
      break

    case "postalCode":
      if (value && !/^[A-Z0-9]{3,10}$/i.test(value)) {
        isValid = false
        errorMessage = "Please enter a valid postal code"
      }
      break
  }

  // Update field appearance and error message
  if (isValid) {
    field.classList.remove("invalid")
    if (errorElement) errorElement.textContent = ""
  } else {
    field.classList.add("invalid")
    if (errorElement) {
      errorElement.textContent = errorMessage
      announceToScreenReader(errorMessage)
    }
  }

  return isValid
}

function validateForm() {
  const form = document.getElementById("checkoutForm")
  const requiredFields = form.querySelectorAll("[required]")
  let isFormValid = true

  requiredFields.forEach((field) => {
    if (!validateField(field)) {
      isFormValid = false
    }
  })

  return isFormValid
}

// Quantity Management
function updateQuantity(itemId, change) {
  try {
    const item = orderData.items.find((item) => item.id === itemId)
    if (!item) return

    const newQuantity = Math.max(1, Math.min(10, item.quantity + change))

    if (newQuantity !== item.quantity) {
      item.quantity = newQuantity

      // Update UI
      const quantityInput = document.querySelector(`[data-item="${itemId}"]`)
      if (quantityInput) {
        quantityInput.value = newQuantity
      }

      // Update totals
      updateOrderTotals()

      // Announce to screen readers
      announceToScreenReader(`${item.name} quantity updated to ${newQuantity}`)

      console.log(`Updated ${itemId} quantity to ${newQuantity}`)
    }
  } catch (error) {
    handleError(error, "quantity update")
  }
}

function setupQuantityControls() {
  const quantityButtons = document.querySelectorAll(".quantity-btn")

  quantityButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const itemId = this.dataset.item
      const isIncrease = this.classList.contains("increase")
      const change = isIncrease ? 1 : -1

      updateQuantity(itemId, change)
    })
  })

  // Handle direct input changes
  const quantityInputs = document.querySelectorAll(".quantity-input")
  quantityInputs.forEach((input) => {
    input.addEventListener("change", function () {
      const itemId = this.dataset.item
      const newQuantity = Number.parseInt(this.value)
      const item = orderData.items.find((item) => item.id === itemId)

      if (item && !isNaN(newQuantity) && newQuantity >= 1 && newQuantity <= 10) {
        const change = newQuantity - item.quantity
        updateQuantity(itemId, change)
      } else {
        // Reset to current quantity if invalid
        this.value = item ? item.quantity : 1
      }
    })
  })
}

// Order Totals Calculation
function calculateSubtotal() {
  return orderData.items.reduce((total, item) => {
    return total + item.price * item.quantity
  }, 0)
}

function calculateDeliveryFee() {
  return orderData.deliveryFee[orderData.selectedDelivery]
}

function calculateTotal() {
  return calculateSubtotal() + calculateDeliveryFee()
}

function updateOrderTotals() {
  try {
    const subtotal = calculateSubtotal()
    const deliveryFee = calculateDeliveryFee()
    const total = calculateTotal()

    // Update UI elements
    const subtotalElement = document.getElementById("subtotal")
    const deliveryFeeElement = document.getElementById("deliveryFee")
    const orderTotalElement = document.getElementById("orderTotal")

    if (subtotalElement) subtotalElement.textContent = formatPrice(subtotal)
    if (deliveryFeeElement) deliveryFeeElement.textContent = formatPrice(deliveryFee)
    if (orderTotalElement) orderTotalElement.textContent = formatPrice(total)

    // Update order total description for screen readers
    const orderTotalDesc = document.getElementById("order-total-desc")
    if (orderTotalDesc) {
      orderTotalDesc.textContent = `Confirm your order for a total of ${formatPrice(total)}`
    }

    console.log(
      `Order totals updated: Subtotal ${formatPrice(subtotal)}, Delivery ${formatPrice(deliveryFee)}, Total ${formatPrice(total)}`,
    )
  } catch (error) {
    handleError(error, "order totals calculation")
  }
}

// Delivery Method Selection
function setupDeliveryMethod() {
  const deliveryRadios = document.querySelectorAll('input[name="deliveryMethod"]')

  deliveryRadios.forEach((radio) => {
    radio.addEventListener("change", function () {
      if (this.checked) {
        orderData.selectedDelivery = this.value
        updateOrderTotals()

        const deliveryType = this.value === "standard" ? "Standard Delivery (2-3 Days)" : "Express Delivery (1 Day)"
        announceToScreenReader(`${deliveryType} selected`)

        console.log(`Delivery method changed to: ${this.value}`)
      }
    })
  })
}

// Form Submission
function setupFormSubmission() {
  const form = document.getElementById("checkoutForm")
  const confirmButton = document.querySelector(".confirm-order-btn")

  if (!form || !confirmButton) return

  form.addEventListener("submit", (e) => {
    e.preventDefault()

    try {
      // Validate form
      if (!validateForm()) {
        announceToScreenReader("Please correct the errors in the form")
        return
      }

      // Disable button and show loading state
      confirmButton.disabled = true
      confirmButton.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Processing...'

      // Collect form data
      const formData = new FormData(form)
      const orderDetails = {
        customer: {
          firstName: formData.get("firstName"),
          lastName: formData.get("lastName"),
          address: formData.get("address"),
          postalCode: formData.get("postalCode"),
          region: formData.get("region"),
          cityTown: formData.get("cityTown"),
          phoneNumber: formData.get("phoneNumber"),
        },
        delivery: {
          method: formData.get("deliveryMethod"),
          fee: calculateDeliveryFee(),
        },
        payment: {
          network: formData.get("network"),
          number: formData.get("paymentNumber"),
        },
        items: orderData.items,
        totals: {
          subtotal: calculateSubtotal(),
          deliveryFee: calculateDeliveryFee(),
          total: calculateTotal(),
        },
      }

      console.log("Order submitted:", orderDetails)

      // Simulate API call
      setTimeout(() => {
        // Show success message
        showSuccessMessage()

        // Reset button
        confirmButton.disabled = false
        confirmButton.innerHTML = "Confirm order"

        announceToScreenReader("Order confirmed successfully!")
      }, 2000)
    } catch (error) {
      handleError(error, "form submission")

      // Reset button on error
      confirmButton.disabled = false
      confirmButton.innerHTML = "Confirm order"
    }
  })
}

function showSuccessMessage() {
  const successMessage = document.createElement("div")
  successMessage.className = "success-message"
  successMessage.innerHTML = `
    <i class="fas fa-check-circle" aria-hidden="true"></i>
    <div>
      <strong>Order confirmed!</strong>
      <p>You will receive a confirmation call shortly.</p>
    </div>
  `

  const form = document.querySelector(".checkout-form")
  form.insertBefore(successMessage, form.firstChild)

  // Remove message after 5 seconds
  setTimeout(() => {
    if (successMessage.parentNode) {
      successMessage.parentNode.removeChild(successMessage)
    }
  }, 5000)
}

// Real-time Form Validation
function setupRealTimeValidation() {
  const formInputs = document.querySelectorAll(".form-input, .form-select")

  formInputs.forEach((input) => {
    // Validate on blur (when user leaves field)
    input.addEventListener("blur", function () {
      validateField(this)
    })

    // Clear errors on input (when user starts typing)
    input.addEventListener("input", function () {
      if (this.classList.contains("invalid")) {
        const errorElement = document.getElementById(`${this.id}-error`)
        if (errorElement) {
          errorElement.textContent = ""
        }
        this.classList.remove("invalid")
      }
    })
  })
}

// Search Functionality
function setupSearch() {
  const searchInput = document.getElementById("searchInput")

  if (!searchInput) return

  const debouncedSearch = debounce((searchTerm) => {
    console.log(`Searching for: ${searchTerm}`)

    if (searchTerm.length > 2) {
      announceToScreenReader(`Searching for ${searchTerm}`)
    } else if (searchTerm.length === 0) {
      announceToScreenReader("Search cleared")
    }
  }, 300)

  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase().trim()
    debouncedSearch(searchTerm)
  })

  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault()
      const searchTerm = this.value.trim()
      if (searchTerm) {
        announceToScreenReader(`Searching for ${searchTerm}`)
        console.log(`Search submitted: ${searchTerm}`)
      }
    }
  })
}

// Keyboard Navigation
function setupKeyboardNavigation() {
  document.addEventListener("keydown", (e) => {
    try {
      // Keyboard shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "k":
            e.preventDefault()
            const searchInput = document.getElementById("searchInput")
            if (searchInput) {
              searchInput.focus()
              announceToScreenReader("Search focused")
            }
            break

          case "Enter":
            // Submit form with Ctrl+Enter
            if (e.target.tagName !== "BUTTON") {
              e.preventDefault()
              const form = document.getElementById("checkoutForm")
              if (form) {
                form.dispatchEvent(new Event("submit"))
              }
            }
            break
        }
      }
    } catch (error) {
      handleError(error, "keyboard navigation")
    }
  })
}

// Auto-save Form Data (localStorage)
function setupAutoSave() {
  const form = document.getElementById("checkoutForm")
  if (!form) return

  // Load saved data
  const savedData = localStorage.getItem("checkoutFormData")
  if (savedData) {
    try {
      const data = JSON.parse(savedData)
      Object.keys(data).forEach((key) => {
        const field = form.querySelector(`[name="${key}"]`)
        if (field && field.type !== "radio") {
          field.value = data[key]
        } else if (field && field.type === "radio" && field.value === data[key]) {
          field.checked = true
        }
      })
    } catch (error) {
      console.warn("Failed to load saved form data:", error)
    }
  }

  // Save data on input
  const debouncedSave = debounce(() => {
    try {
      const formData = new FormData(form)
      const data = Object.fromEntries(formData.entries())
      localStorage.setItem("checkoutFormData", JSON.stringify(data))
    } catch (error) {
      console.warn("Failed to save form data:", error)
    }
  }, 1000)

  form.addEventListener("input", debouncedSave)
  form.addEventListener("change", debouncedSave)
}

// Clear saved data on successful submission
function clearSavedData() {
  localStorage.removeItem("checkoutFormData")
}

// Performance Monitoring
function setupPerformanceMonitoring() {
  window.addEventListener("load", () => {
    if (window.performance && window.performance.timing) {
      const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart
      console.log(`Checkout page load time: ${loadTime}ms`)

      if (loadTime > 3000) {
        console.warn("Checkout page load time is slow. Consider optimization.")
      }
    }
  })
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  try {
    // Initialize all components
    setupQuantityControls()
    setupDeliveryMethod()
    setupFormSubmission()
    setupRealTimeValidation()
    setupSearch()
    setupKeyboardNavigation()
    setupAutoSave()
    setupPerformanceMonitoring()

    // Calculate initial totals
    updateOrderTotals()

    // Announce page load
    announceToScreenReader("Checkout page loaded successfully")

    console.log("Grace Clothing Checkout Page initialized successfully!")
  } catch (error) {
    handleError(error, "initialization")
  }
})

// Handle page visibility changes
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    console.log("Checkout page is now visible")
    // Refresh totals if needed
    updateOrderTotals()
  }
})

// Export functions for testing (if needed)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    validateField,
    validateForm,
    updateQuantity,
    calculateSubtotal,
    calculateDeliveryFee,
    calculateTotal,
    formatPrice,
  }
}
