// Product data
const currentProduct = {
  id: 1,
  name: "Men's Shirt Short Sleeve",
  price: 120.99,
  originalPrice: 140.99,
  rating: 4.9,
  reviews: 142,
  sizes: ["S", "M", "L", "XL", "2XL"],
  image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=600&fit=crop",
}

const recommendedProducts = [
  {
    id: 2,
    name: "3 Pieces of T-Shirt",
    category: "Men's Fashion",
    price: "GHC150.99",
    originalPrice: "GHC200",
    rating: 4.9,
    reviews: 98,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
    alt: "Pack of 3 colorful t-shirts for men",
  },
  {
    id: 3,
    name: "Crop Top",
    category: "Women's Fashion",
    price: "GHC80.99",
    originalPrice: "GHC99",
    rating: 4.9,
    reviews: 98,
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=300&h=300&fit=crop",
    alt: "Stylish women's crop top in neutral colors",
  },
  {
    id: 4,
    name: "Black School Bag",
    category: "Accessories",
    price: "GHC100",
    originalPrice: "GHC120",
    rating: 4.9,
    reviews: 98,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
    alt: "Durable black school backpack with multiple compartments",
  },
  {
    id: 5,
    name: "3 Pieces of Boxers",
    category: "Underwear",
    price: "GHC85",
    originalPrice: "GHC100",
    rating: 4.9,
    reviews: 98,
    image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=300&h=300&fit=crop",
    alt: "Comfortable men's boxer shorts pack of 3",
  },
]

// State management
let selectedSize = "S"
let quantity = 1
const basePrice = currentProduct.price
const wishlistItems = new Set()

// Utility Functions
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

function announceToScreenReader(message) {
  const announcement = document.getElementById("announcements")
  if (announcement) {
    announcement.textContent = message
    setTimeout(() => {
      announcement.textContent = ""
    }, 1000)
  }
}

function handleError(error, context) {
  console.error(`Error in ${context}:`, error)
  announceToScreenReader(`An error occurred. Please try again.`)
}

// Generate star rating HTML with accessibility
function generateStars(rating, productName = "") {
  const fullStars = Math.floor(rating)
  let starsHTML = ""

  for (let i = 0; i < 5; i++) {
    if (i < fullStars) {
      starsHTML += '<i class="fas fa-star" aria-hidden="true"></i>'
    } else {
      starsHTML += '<i class="far fa-star" aria-hidden="true"></i>'
    }
  }

  const ariaLabel = productName ? `${rating} out of 5 stars for ${productName}` : `${rating} out of 5 stars`

  return `<div class="recommended-stars" role="img" aria-label="${ariaLabel}">${starsHTML}</div>`
}

// Create recommended product card with full accessibility
function createRecommendedCard(product) {
  const isWishlisted = wishlistItems.has(product.id)
  const wishlistClass = isWishlisted ? "active" : ""
  const wishlistIcon = isWishlisted ? "fas" : "far"
  const wishlistLabel = isWishlisted ? "Remove from wishlist" : "Add to wishlist"

  return `
        <article class="recommended-card" role="listitem" aria-labelledby="product-${product.id}-name">
            <div class="recommended-image">
                <img src="${product.image}" alt="${product.alt}" loading="lazy">
                <button 
                    class="wishlist-btn ${wishlistClass}" 
                    onclick="toggleWishlist(${product.id})"
                    aria-label="${wishlistLabel}: ${product.name}"
                    data-product-id="${product.id}"
                    type="button"
                >
                    <i class="${wishlistIcon} fa-heart" aria-hidden="true"></i>
                </button>
            </div>
            <div class="recommended-info">
                <h3 class="recommended-name" id="product-${product.id}-name">${product.name}</h3>
                <p class="recommended-category">${product.category}</p>
                <div class="recommended-price">
                    <span class="recommended-current-price" aria-label="Current price">${product.price}</span>
                    <span class="recommended-original-price" aria-label="Original price">${product.originalPrice}</span>
                </div>
                <div class="recommended-rating">
                    ${generateStars(product.rating, product.name)}
                    <span class="recommended-rating-text" aria-label="${product.reviews} reviews">${product.rating} (${product.reviews})</span>
                </div>
            </div>
        </article>
    `
}

// Render recommended products with loading state
function renderRecommendedProducts() {
  const container = document.getElementById("recommendedProducts")
  if (!container) return

  // Show loading state
  container.innerHTML = '<div class="loading" role="status" aria-live="polite">Loading recommended products...</div>'

  // Simulate loading delay for better UX
  setTimeout(() => {
    container.innerHTML = recommendedProducts.map((product) => createRecommendedCard(product)).join("")
    announceToScreenReader(`${recommendedProducts.length} recommended products loaded`)
  }, 300)
}

// Size selection functionality with accessibility
function setupSizeSelection() {
  const sizeButtons = document.querySelectorAll(".size-btn")
  const selectedSizeDisplay = document.getElementById("selectedSize")

  if (!sizeButtons.length || !selectedSizeDisplay) return

  sizeButtons.forEach((button) => {
    button.addEventListener("click", function () {
      try {
        // Remove active class and aria-checked from all buttons
        sizeButtons.forEach((btn) => {
          btn.classList.remove("active")
          btn.setAttribute("aria-checked", "false")
        })

        // Add active class and aria-checked to clicked button
        this.classList.add("active")
        this.setAttribute("aria-checked", "true")

        // Update selected size
        selectedSize = this.dataset.size
        selectedSizeDisplay.textContent = selectedSize

        // Announce to screen readers
        const sizeName = this.getAttribute("aria-label")
        announceToScreenReader(`${sizeName} selected`)

        console.log(`Size selected: ${selectedSize}`)
      } catch (error) {
        handleError(error, "size selection")
      }
    })

    // Keyboard navigation for size buttons
    button.addEventListener("keydown", function (e) {
      const buttons = Array.from(sizeButtons)
      const currentIndex = buttons.indexOf(this)
      let nextIndex

      switch (e.key) {
        case "ArrowLeft":
        case "ArrowUp":
          e.preventDefault()
          nextIndex = currentIndex > 0 ? currentIndex - 1 : buttons.length - 1
          buttons[nextIndex].focus()
          break
        case "ArrowRight":
        case "ArrowDown":
          e.preventDefault()
          nextIndex = currentIndex < buttons.length - 1 ? currentIndex + 1 : 0
          buttons[nextIndex].focus()
          break
        case "Enter":
        case " ":
          e.preventDefault()
          this.click()
          break
      }
    })
  })
}

// Quantity functionality with validation and accessibility
function setupQuantityControls() {
  const quantityInput = document.getElementById("quantityInput")
  const decreaseBtn = document.getElementById("decreaseBtn")
  const increaseBtn = document.getElementById("increaseBtn")
  const quantityDisplay = document.getElementById("quantityDisplay")
  const subtotalDisplay = document.getElementById("subtotalDisplay")
  const totalDisplay = document.getElementById("totalDisplay")

  if (!quantityInput || !decreaseBtn || !increaseBtn) return

  function updateQuantity(newQuantity) {
    try {
      if (newQuantity < 1 || newQuantity > 10) return

      quantity = newQuantity
      quantityInput.value = quantity

      if (quantityDisplay) quantityDisplay.textContent = quantity

      // Update price calculations
      const subtotal = (basePrice * quantity).toFixed(2)
      if (subtotalDisplay) subtotalDisplay.textContent = `GHC${subtotal}`
      if (totalDisplay) totalDisplay.textContent = `GHC${subtotal}`

      // Update button states
      decreaseBtn.disabled = quantity <= 1
      increaseBtn.disabled = quantity >= 10

      decreaseBtn.setAttribute("aria-disabled", quantity <= 1)
      increaseBtn.setAttribute("aria-disabled", quantity >= 10)

      // Announce to screen readers
      announceToScreenReader(`Quantity updated to ${quantity}`)

      console.log(`Quantity updated: ${quantity}`)
    } catch (error) {
      handleError(error, "quantity update")
    }
  }

  decreaseBtn.addEventListener("click", () => {
    updateQuantity(quantity - 1)
  })

  increaseBtn.addEventListener("click", () => {
    updateQuantity(quantity + 1)
  })

  quantityInput.addEventListener("change", (e) => {
    const newQuantity = Number.parseInt(e.target.value)
    if (!isNaN(newQuantity)) {
      updateQuantity(newQuantity)
    }
  })

  // Initialize button states
  updateQuantity(quantity)
}

// Add to cart functionality with feedback
function setupAddToCart() {
  const addToCartBtn = document.querySelector(".add-to-cart-btn")

  if (!addToCartBtn) return

  addToCartBtn.addEventListener("click", function () {
    try {
      const cartItem = {
        productId: currentProduct.id,
        name: currentProduct.name,
        size: selectedSize,
        quantity: quantity,
        price: basePrice,
        total: (basePrice * quantity).toFixed(2),
      }

      console.log("Added to cart:", cartItem)

      // Show success feedback
      const originalText = this.innerHTML
      const originalBg = this.style.background

      this.innerHTML = '<i class="fas fa-check" aria-hidden="true"></i> Added to cart!'
      this.style.background = "#10b981"
      this.setAttribute("aria-label", "Item added to cart successfully")

      // Announce success to screen readers
      announceToScreenReader(`${currentProduct.name} in size ${selectedSize} added to cart`)

      setTimeout(() => {
        this.innerHTML = originalText
        this.style.background = originalBg
        this.setAttribute("aria-label", "Add this item to your shopping cart")
      }, 2000)

      // Update cart badge
      updateCartBadge()
    } catch (error) {
      handleError(error, "add to cart")
    }
  })
}

// Update cart badge with animation
function updateCartBadge() {
  const cartBadge = document.querySelector(".cart-badge")
  if (!cartBadge) return

  const currentCount = Number.parseInt(cartBadge.textContent) || 0
  const newCount = currentCount + quantity

  cartBadge.textContent = newCount
  cartBadge.style.transform = "scale(1.2)"

  setTimeout(() => {
    cartBadge.style.transform = "scale(1)"
  }, 200)
}

// Toggle wishlist with accessibility feedback
function toggleWishlist(productId) {
  try {
    const product = recommendedProducts.find((p) => p.id === productId)
    const button = document.querySelector(`[data-product-id="${productId}"]`)

    if (!button || !product) return

    const icon = button.querySelector("i")

    if (wishlistItems.has(productId)) {
      wishlistItems.delete(productId)
      icon.classList.remove("fas")
      icon.classList.add("far")
      button.classList.remove("active")
      button.setAttribute("aria-label", `Add to wishlist: ${product.name}`)
      announceToScreenReader(`${product.name} removed from wishlist`)
    } else {
      wishlistItems.add(productId)
      icon.classList.remove("far")
      icon.classList.add("fas")
      button.classList.add("active")
      button.setAttribute("aria-label", `Remove from wishlist: ${product.name}`)
      announceToScreenReader(`${product.name} added to wishlist`)
    }
  } catch (error) {
    handleError(error, "wishlist toggle")
  }
}

// Search functionality with debouncing and accessibility
function setupSearch() {
  const searchInput = document.getElementById("searchInput")

  if (!searchInput) return

  const debouncedSearch = debounce((searchTerm) => {
    console.log(`Searching for: ${searchTerm}`)

    if (searchTerm.length > 2) {
      announceToScreenReader(`Searching for ${searchTerm}`)
      // Here you would typically perform the actual search
      console.log("Performing search...")
    } else if (searchTerm.length === 0) {
      announceToScreenReader("Search cleared")
    }
  }, 300)

  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase().trim()
    debouncedSearch(searchTerm)
  })

  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault()
      const searchTerm = this.value.trim()
      if (searchTerm) {
        announceToScreenReader(`Searching for ${searchTerm}`)
        console.log(`Search submitted: ${searchTerm}`)
      }
    }
  })
}

// Image zoom functionality with accessibility
function setupImageZoom() {
  const productImage = document.getElementById("mainProductImage")

  if (!productImage) return

  function openImageModal() {
    const modal = document.createElement("div")
    modal.className = "image-modal"
    modal.setAttribute("role", "dialog")
    modal.setAttribute("aria-modal", "true")
    modal.setAttribute("aria-labelledby", "modal-title")

    modal.innerHTML = `
            <div class="modal-backdrop" onclick="closeImageModal()">
                <img src="${productImage.src}" alt="${productImage.alt}" class="zoomed-image">
                <button class="close-modal" onclick="closeImageModal()" aria-label="Close image zoom" type="button">&times;</button>
                <div id="modal-title" class="sr-only">Zoomed product image</div>
            </div>
        `

    document.body.appendChild(modal)
    document.body.style.overflow = "hidden"

    // Focus the close button for accessibility
    const closeBtn = modal.querySelector(".close-modal")
    closeBtn.focus()

    announceToScreenReader("Image zoomed. Press Escape or click close to exit.")
  }

  productImage.addEventListener("click", openImageModal)
  productImage.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault()
      openImageModal()
    }
  })
}

// Close image modal with accessibility
function closeImageModal() {
  const modal = document.querySelector(".image-modal")
  if (modal) {
    document.body.removeChild(modal)
    document.body.style.overflow = "auto"

    // Return focus to the product image
    const productImage = document.getElementById("mainProductImage")
    if (productImage) {
      productImage.focus()
    }

    announceToScreenReader("Image zoom closed")
  }
}

// Keyboard navigation enhancements
function setupKeyboardNavigation() {
  document.addEventListener("keydown", (e) => {
    try {
      // ESC key to close modals
      if (e.key === "Escape") {
        closeImageModal()
      }

      // Arrow keys for quantity when focused
      if (e.target.id === "quantityInput") {
        if (e.key === "ArrowUp") {
          e.preventDefault()
          document.getElementById("increaseBtn").click()
        } else if (e.key === "ArrowDown") {
          e.preventDefault()
          document.getElementById("decreaseBtn").click()
        }
      }

      // Keyboard shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "k":
            e.preventDefault()
            const searchInput = document.getElementById("searchInput")
            if (searchInput) {
              searchInput.focus()
              announceToScreenReader("Search focused")
            }
            break
        }
      }
    } catch (error) {
      handleError(error, "keyboard navigation")
    }
  })
}

// Smooth scrolling for anchor links
function setupSmoothScrolling() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })

        // Announce navigation to screen readers
        const targetText = target.textContent || target.getAttribute("aria-label") || "section"
        announceToScreenReader(`Navigated to ${targetText}`)
      }
    })
  })
}

// Performance monitoring
function setupPerformanceMonitoring() {
  window.addEventListener("load", () => {
    if (window.performance && window.performance.timing) {
      const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart
      console.log(`Page load time: ${loadTime}ms`)

      // Log performance metrics for optimization
      if (loadTime > 3000) {
        console.warn("Page load time is slow. Consider optimization.")
      }
    }
  })
}

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  try {
    // Initialize all components
    renderRecommendedProducts()
    setupSizeSelection()
    setupQuantityControls()
    setupAddToCart()
    setupSearch()
    setupImageZoom()
    setupKeyboardNavigation()
    setupSmoothScrolling()
    setupPerformanceMonitoring()

    // Announce page load to screen readers
    announceToScreenReader("Grace Clothing product page loaded successfully")

    console.log("Grace Clothing Product Page initialized successfully!")
  } catch (error) {
    handleError(error, "initialization")
  }
})

// Handle page visibility changes for performance
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    console.log("Product page is now visible")
    // Refresh data if needed when page becomes visible
  }
})

// Service worker registration for offline support (optional)
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .then((registration) => {
        console.log("ServiceWorker registration successful")
      })
      .catch((err) => {
        console.log("ServiceWorker registration failed")
      })
  })
}

// Export functions for testing (if needed)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    toggleWishlist,
    closeImageModal,
    generateStars,
    createRecommendedCard,
  }
}
