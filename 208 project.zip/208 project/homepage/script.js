// Utility Functions
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

function announceToScreenReader(message) {
  const announcement = document.getElementById("announcements")
  if (announcement) {
    announcement.textContent = message
    setTimeout(() => {
      announcement.textContent = ""
    }, 1000)
  }
}

function handleError(error, context) {
  console.error(`Error in ${context}:`, error)
  announceToScreenReader("An error occurred. Please try again.")
}

function clearSavedData() {
  // Clear saved form data logic here
  console.log("Saved form data cleared")
}

// Password Strength Checker
function checkPasswordStrength(password) {
  let score = 0
  const feedback = []

  // Length check
  if (password.length >= 8) score += 1
  else feedback.push("at least 8 characters")

  // Uppercase check
  if (/[A-Z]/.test(password)) score += 1
  else feedback.push("uppercase letter")

  // Lowercase check
  if (/[a-z]/.test(password)) score += 1
  else feedback.push("lowercase letter")

  // Number check
  if (/\d/.test(password)) score += 1
  else feedback.push("number")

  // Special character check
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score += 1
  else feedback.push("special character")

  const strength = score <= 1 ? "weak" : score <= 2 ? "fair" : score <= 3 ? "good" : "strong"
  const strengthText = score <= 1 ? "Weak" : score <= 2 ? "Fair" : score <= 3 ? "Good" : "Strong"

  return {
    score,
    strength,
    strengthText,
    feedback,
    isValid: score >= 3,
  }
}

function updatePasswordStrength(password) {
  const strengthIndicator = document.getElementById("passwordStrength")
  const strengthFill = document.getElementById("strengthFill")
  const strengthText = document.getElementById("strengthText")

  if (!password) {
    strengthFill.className = "strength-fill"
    strengthText.textContent = "Password strength"
    strengthText.className = "strength-text"
    return
  }

  const result = checkPasswordStrength(password)

  strengthFill.className = `strength-fill ${result.strength}`
  strengthText.textContent = `${result.strengthText} password`
  strengthText.className = `strength-text ${result.strength}`

  if (result.feedback.length > 0 && password.length > 0) {
    const missing = result.feedback.slice(0, 2).join(", ")
    strengthText.textContent += ` - Add ${missing}`
  }
}

// Form Validation
function validateField(field) {
  const value = field.value.trim()
  const fieldName = field.name
  const errorElement = document.getElementById(`${field.id}-error`)

  let isValid = true
  let errorMessage = ""

  // Required field validation
  if (field.hasAttribute("required") && !value) {
    isValid = false
    errorMessage = `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`
  }

  // Specific field validations
  switch (fieldName) {
    case "email":
      if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        isValid = false
        errorMessage = "Please enter a valid email address"
      }
      break

    case "password":
      if (value) {
        const strength = checkPasswordStrength(value)
        if (!strength.isValid) {
          isValid = false
          errorMessage = "Password must be at least 8 characters with uppercase, lowercase, and number"
        }
      }
      break

    case "confirmPassword":
      const passwordField = document.getElementById("password")
      if (value && value !== passwordField.value) {
        isValid = false
        errorMessage = "Passwords do not match"
      }
      break

    case "agreeTerms":
      if (!field.checked) {
        isValid = false
        errorMessage = "You must agree to the Terms of Service and Privacy Policy"
      }
      break
  }

  // Update field appearance and error message
  if (isValid) {
    field.classList.remove("invalid")
    if (errorElement) errorElement.textContent = ""
  } else {
    field.classList.add("invalid")
    if (errorElement) {
      errorElement.textContent = errorMessage
      announceToScreenReader(errorMessage)
    }
  }

  return isValid
}

function validateForm() {
  const form = document.getElementById("registerForm")
  const requiredFields = form.querySelectorAll("[required]")
  let isFormValid = true

  requiredFields.forEach((field) => {
    if (!validateField(field)) {
      isFormValid = false
    }
  })

  return isFormValid
}

// Password Toggle Functionality
function setupPasswordToggle() {
  const passwordToggles = document.querySelectorAll(".password-toggle")

  passwordToggles.forEach((toggle) => {
    toggle.addEventListener("click", function () {
      const passwordInput = this.parentNode.querySelector(".password-input")
      const isPassword = passwordInput.type === "password"

      // Toggle input type
      passwordInput.type = isPassword ? "text" : "password"

      // Toggle icon
      const icon = this.querySelector("i")
      icon.className = isPassword ? "fas fa-eye-slash" : "fas fa-eye"

      // Update aria-label
      this.setAttribute("aria-label", isPassword ? "Hide password" : "Show password")

      // Announce to screen readers
      announceToScreenReader(isPassword ? "Password shown" : "Password hidden")

      // Keep focus on password input
      passwordInput.focus()
    })
  })
}

// Registration Form Submission
function setupRegistrationForm() {
  const form = document.getElementById("registerForm")
  const submitButton = document.querySelector(".continue-btn")

  if (!form || !submitButton) return

  form.addEventListener("submit", async (e) => {
    e.preventDefault()

    try {
      // Validate form
      if (!validateForm()) {
        announceToScreenReader("Please correct the errors in the form")
        return
      }

      // Show loading state
      submitButton.disabled = true
      submitButton.classList.add("loading")

      // Collect form data
      const formData = new FormData(form)
      const registrationData = {
        email: formData.get("email"),
        password: formData.get("password"),
        confirmPassword: formData.get("confirmPassword"),
        agreeTerms: formData.get("agreeTerms") === "on",
        newsletter: formData.get("newsletter") === "on",
        timestamp: new Date().toISOString(),
      }

      console.log("Registration attempt:", {
        ...registrationData,
        password: "[REDACTED]",
        confirmPassword: "[REDACTED]",
      })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2500))

      // Simulate registration success/failure
      const isSuccess = Math.random() > 0.2 // 80% success rate for demo

      if (isSuccess) {
        // Show success message
        showSuccessMessage("Account created successfully! Please check your email to verify your account.")

        // Clear saved form data
        clearSavedData()

        // Simulate redirect after delay
        setTimeout(() => {
          announceToScreenReader("Redirecting to login page")
          console.log("Redirecting to login page...")
          // window.location.href = "/login"
        }, 2000)
      } else {
        // Show error message
        showErrorMessage("Registration failed. This email may already be registered.")
      }

      // Reset button state
      submitButton.disabled = false
      submitButton.classList.remove("loading")
    } catch (error) {
      handleError(error, "registration form submission")

      // Reset button state on error
      submitButton.disabled = false
      submitButton.classList.remove("loading")
    }
  })
}

function showSuccessMessage(message) {
  const successMessage = document.createElement("div")
  successMessage.className = "success-message"
  successMessage.innerHTML = `
    <i class="fas fa-check-circle" aria-hidden="true"></i>
    <div>
      <strong>${message}</strong>
    </div>
  `

  const form = document.getElementById("registerForm")
  form.parentNode.insertBefore(successMessage, form)

  announceToScreenReader(message)

  // Remove message after 4 seconds
  setTimeout(() => {
    if (successMessage.parentNode) {
      successMessage.parentNode.removeChild(successMessage)
    }
  }, 4000)
}

function showErrorMessage(message) {
  const errorMessage = document.createElement("div")
  errorMessage.className = "error-message"
  errorMessage.style.cssText = `
    background: #fef2f2;
    border: 1px solid #fecaca;
    color: #dc2626;
    padding: 1rem;
    border-radius: 0.375rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  `
  errorMessage.innerHTML = `
    <i class="fas fa-exclamation-circle" aria-hidden="true"></i>
    <div>
      <strong>${message}</strong>
    </div>
  `

  const form = document.getElementById("registerForm")
  form.parentNode.insertBefore(errorMessage, form)

  announceToScreenReader(message)

  // Remove message after 5 seconds
  setTimeout(() => {
    if (errorMessage.parentNode) {
      errorMessage.parentNode.removeChild(errorMessage)
    }
  }, 5000)
}

// Real-time Form Validation
function setupRealTimeValidation() {
  const formInputs = document.querySelectorAll(".form-input")
  const passwordInput = document.getElementById("password")
  const confirmPasswordInput = document.getElementById("confirmPassword")

  formInputs.forEach((input) => {
    // Validate on blur (when user leaves field)
    input.addEventListener("blur", function () {
      validateField(this)
    })

    // Clear errors on input (when user starts typing)
    input.addEventListener("input", function () {
      if (this.classList.contains("invalid")) {
        const errorElement = document.getElementById(`${this.id}-error`)
        if (errorElement) {
          errorElement.textContent = ""
        }
        this.classList.remove("invalid")
      }
    })
  })

  // Password strength checking
  if (passwordInput) {
    passwordInput.addEventListener("input", function () {
      updatePasswordStrength(this.value)

      // Also validate confirm password if it has a value
      if (confirmPasswordInput && confirmPasswordInput.value) {
        validateField(confirmPasswordInput)
      }
    })
  }

  // Confirm password validation
  if (confirmPasswordInput) {
    confirmPasswordInput.addEventListener("input", function () {
      if (this.value) {
        validateField(this)
      }
    })
  }
}

// Social Registration Handlers
function setupSocialRegistration() {
  const socialButtons = document.querySelectorAll(".social-btn")

  socialButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const platform = this.classList.contains("google-btn") ? "Google" : "Facebook"

      console.log(`${platform} registration clicked`)
      announceToScreenReader(`Opening ${platform} registration`)

      // Simulate social registration
      this.disabled = true
      this.innerHTML = `<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Connecting to ${platform}...`

      setTimeout(() => {
        this.disabled = false
        this.innerHTML = this.classList.contains("google-btn")
          ? '<i class="fab fa-google" aria-hidden="true"></i><span>Register with Google</span>'
          : '<i class="fab fa-facebook-f" aria-hidden="true"></i><span>Register with Facebook</span>'

        showSuccessMessage(`${platform} registration successful!`)
      }, 2000)
    })
  })
}

// Search Functionality
function setupSearch() {
  const searchInput = document.getElementById("searchInput")

  if (!searchInput) return

  const debouncedSearch = debounce((searchTerm) => {
    console.log(`Searching for: ${searchTerm}`)

    if (searchTerm.length > 2) {
      announceToScreenReader(`Searching for ${searchTerm}`)
      performSearch(searchTerm)
    } else if (searchTerm.length === 0) {
      announceToScreenReader("Search cleared")
      clearSearchResults()
    }
  }, 300)

  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase().trim()
    debouncedSearch(searchTerm)
  })

  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault()
      const searchTerm = this.value.trim()
      if (searchTerm) {
        announceToScreenReader(`Searching for ${searchTerm}`)
        console.log(`Search submitted: ${searchTerm}`)
        performSearch(searchTerm)
      }
    }
  })
}

function performSearch(searchTerm) {
  // Simulate search functionality
  console.log(`Performing search for: ${searchTerm}`)
  // In a real application, this would make an API call
}

function clearSearchResults() {
  console.log("Clearing search results")
  // In a real application, this would clear the search results
}

// Hero Slider Functionality
function setupHeroSlider() {
  const heroDots = document.querySelectorAll(".hero-section .pagination-dot")
  let currentSlide = 0

  const heroSlides = [
    {
      title: "Exclusive collection for everyone",
      image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=600&h=700&fit=crop",
      alt: "Woman in elegant black outfit showcasing our exclusive collection",
    },
    {
      title: "New Arrivals Just In",
      image: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=600&h=700&fit=crop",
      alt: "Latest fashion trends and new arrivals",
    },
    {
      title: "Premium Quality Fashion",
      image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600&h=700&fit=crop",
      alt: "Premium quality clothing and accessories",
    },
  ]

  function updateHeroSlide(slideIndex) {
    const heroTitle = document.querySelector(".hero-text h1")
    const heroImage = document.querySelector(".hero-img")

    if (heroTitle && heroImage) {
      heroTitle.textContent = heroSlides[slideIndex].title
      heroImage.src = heroSlides[slideIndex].image
      heroImage.alt = heroSlides[slideIndex].alt
    }

    // Update pagination dots
    heroDots.forEach((dot, index) => {
      dot.classList.toggle("active", index === slideIndex)
      dot.setAttribute("aria-selected", index === slideIndex)
    })

    currentSlide = slideIndex
    announceToScreenReader(`Slide ${slideIndex + 1} of ${heroSlides.length}`)
  }

  // Add click handlers to pagination dots
  heroDots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
      updateHeroSlide(index)
    })
  })

  // Auto-advance slides every 5 seconds
  setInterval(() => {
    const nextSlide = (currentSlide + 1) % heroSlides.length
    updateHeroSlide(nextSlide)
  }, 5000)
}

// Wishlist Functionality
function setupWishlist() {
  const wishlistButtons = document.querySelectorAll(".wishlist-btn")
  let wishlistItems = JSON.parse(localStorage.getItem("wishlist")) || []

  // Initialize wishlist button states
  wishlistButtons.forEach((button) => {
    const productCard = button.closest(".product-card")
    const productName = productCard.querySelector(".product-name").textContent
    const isInWishlist = wishlistItems.includes(productName)

    if (isInWishlist) {
      button.classList.add("active")
      button.querySelector("i").className = "fas fa-heart"
    }
  })

  wishlistButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault()
      e.stopPropagation()

      const productCard = this.closest(".product-card")
      const productName = productCard.querySelector(".product-name").textContent
      const isActive = this.classList.contains("active")

      if (isActive) {
        // Remove from wishlist
        this.classList.remove("active")
        this.querySelector("i").className = "far fa-heart"
        wishlistItems = wishlistItems.filter((item) => item !== productName)
        announceToScreenReader(`${productName} removed from wishlist`)
      } else {
        // Add to wishlist
        this.classList.add("active")
        this.querySelector("i").className = "fas fa-heart"
        wishlistItems.push(productName)
        announceToScreenReader(`${productName} added to wishlist`)
      }

      // Save to localStorage
      localStorage.setItem("wishlist", JSON.stringify(wishlistItems))
      console.log("Wishlist updated:", wishlistItems)
    })
  })
}

// Product Card Interactions
function setupProductCards() {
  const productCards = document.querySelectorAll(".product-card")

  productCards.forEach((card) => {
    // Add click handler for product navigation
    card.addEventListener("click", function (e) {
      // Don't navigate if clicking on wishlist button
      if (e.target.closest(".wishlist-btn")) return

      const productName = this.querySelector(".product-name").textContent
      console.log(`Navigating to product: ${productName}`)
      announceToScreenReader(`Opening ${productName} details`)

      // In a real application, this would navigate to the product page
      // window.location.href = `/product/${productSlug}`
    })

    // Add keyboard navigation
    card.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault()
        this.click()
      }
    })

    // Make cards focusable
    card.setAttribute("tabindex", "0")
    card.setAttribute("role", "button")
    card.setAttribute("aria-label", `View details for ${card.querySelector(".product-name").textContent}`)
  })
}

// Category Navigation
function setupCategoryNavigation() {
  const categoryCards = document.querySelectorAll(".category-card")
  const shopButtons = document.querySelectorAll(".shop-btn")

  shopButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const categoryCard = this.closest(".category-card")
      const categoryName = categoryCard.querySelector("h3").textContent

      console.log(`Shopping for: ${categoryName}`)
      announceToScreenReader(`Opening ${categoryName} category`)

      // In a real application, this would navigate to the category page
      // window.location.href = `/category/${categorySlug}`
    })
  })
}

// Pagination Functionality
function setupPagination() {
  const paginationContainers = document.querySelectorAll(".category-pagination, .products-pagination")

  paginationContainers.forEach((container) => {
    const dots = container.querySelectorAll(".pagination-dot")

    dots.forEach((dot, index) => {
      dot.addEventListener("click", function () {
        // Update active state
        dots.forEach((d) => d.classList.remove("active"))
        this.classList.add("active")

        const containerType = container.classList.contains("category-pagination") ? "category" : "products"
        console.log(`${containerType} pagination: page ${index + 1}`)
        announceToScreenReader(`${containerType} page ${index + 1} selected`)

        // In a real application, this would load the corresponding page content
      })
    })
  })
}

// Promotional Section
function setupPromotionalSection() {
  const shopNowBtn = document.querySelector(".shop-now-btn")
  const exploreBtn = document.querySelector(".explore-btn")

  if (shopNowBtn) {
    shopNowBtn.addEventListener("click", () => {
      console.log("Shop now clicked - New Fashion Collection")
      announceToScreenReader("Opening new fashion collection")
      // Navigate to new collection page
    })
  }

  if (exploreBtn) {
    exploreBtn.addEventListener("click", () => {
      console.log("Explore now clicked - Exclusive collection")
      announceToScreenReader("Exploring exclusive collection")
      // Navigate to collection page or scroll to products
      scrollToSection(".recommendations-section")
    })
  }
}

function scrollToSection(selector) {
  const section = document.querySelector(selector)
  if (section) {
    section.scrollIntoView({
      behavior: "smooth",
      block: "start",
    })
  }
}

// Shopping Cart Functionality
function setupShoppingCart() {
  const cartButton = document.querySelector('.icon-button[aria-label*="cart"]')
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || []

  if (cartButton) {
    cartButton.addEventListener("click", () => {
      console.log("Shopping cart clicked")
      announceToScreenReader("Opening shopping cart")
      // In a real application, this would open the cart sidebar or navigate to cart page
    })
  }

  // Update cart badge
  function updateCartBadge() {
    const cartBadge = document.querySelector(".cart-badge")
    if (cartBadge) {
      const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0)
      cartBadge.textContent = totalItems
      cartBadge.setAttribute("aria-label", `${totalItems} items in cart`)
    }
  }

  updateCartBadge()
}

// Keyboard Navigation
function setupKeyboardNavigation() {
  document.addEventListener("keydown", (e) => {
    try {
      // Keyboard shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "k":
            e.preventDefault()
            const searchInput = document.getElementById("searchInput")
            if (searchInput) {
              searchInput.focus()
              announceToScreenReader("Search focused")
            }
            break

          case "h":
            e.preventDefault()
            scrollToSection(".hero-section")
            announceToScreenReader("Navigated to hero section")
            break

          case "p":
            e.preventDefault()
            scrollToSection(".recommendations-section")
            announceToScreenReader("Navigated to products section")
            break
        }
      }

      // Enter key on social buttons
      if (e.key === "Enter" && e.target.classList.contains("social-btn")) {
        e.target.click()
      }
    } catch (error) {
      handleError(error, "keyboard navigation")
    }
  })
}

// Intersection Observer for Animations
function setupScrollAnimations() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1"
        entry.target.style.transform = "translateY(0)"
      }
    })
  }, observerOptions)

  // Observe elements for animation
  const animatedElements = document.querySelectorAll(".product-card, .category-card, .feature-item")
  animatedElements.forEach((element, index) => {
    element.style.opacity = "0"
    element.style.transform = "translateY(30px)"
    element.style.transition = `opacity 0.6s ease-out ${index * 0.1}s, transform 0.6s ease-out ${index * 0.1}s`
    observer.observe(element)
  })
}

// Performance Monitoring
function setupPerformanceMonitoring() {
  window.addEventListener("load", () => {
    if (window.performance && window.performance.timing) {
      const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart
      console.log(`Homepage load time: ${loadTime}ms`)

      if (loadTime > 3000) {
        console.warn("Homepage load time is slow. Consider optimization.")
      }
    }
  })

  // Monitor largest contentful paint
  if ("PerformanceObserver" in window) {
    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries()
      const lastEntry = entries[entries.length - 1]
      console.log(`LCP: ${lastEntry.startTime}ms`)
    })

    observer.observe({ entryTypes: ["largest-contentful-paint"] })
  }
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  try {
    // Initialize all components
    setupPasswordToggle()
    setupRegistrationForm()
    setupRealTimeValidation()
    setupSocialRegistration()
    setupSearch()
    setupHeroSlider()
    setupWishlist()
    setupProductCards()
    setupCategoryNavigation()
    setupPagination()
    setupPromotionalSection()
    setupShoppingCart()
    setupKeyboardNavigation()
    setupScrollAnimations()
    setupPerformanceMonitoring()

    // Focus on email input for better UX
    const emailInput = document.getElementById("email")
    if (emailInput && !emailInput.value) {
      setTimeout(() => emailInput.focus(), 100)
    }

    // Announce page load
    announceToScreenReader("Grace Clothing homepage loaded successfully")

    console.log("Grace Clothing Homepage initialized successfully!")
  } catch (error) {
    handleError(error, "initialization")
  }
})

// Handle page visibility changes
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    console.log("Homepage is now visible")
  }
})

// Handle online/offline status
window.addEventListener("online", () => {
  announceToScreenReader("Connection restored")
  console.log("Back online")
})

window.addEventListener("offline", () => {
  announceToScreenReader("Connection lost")
  console.log("Gone offline")
})

// Export functions for testing (if needed)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    validateField,
    validateForm,
    checkPasswordStrength,
    updatePasswordStrength,
    showSuccessMessage,
    showErrorMessage,
    clearSavedData,
    performSearch,
    clearSearchResults,
    scrollToSection,
    setupWishlist,
    setupProductCards,
  }
}
