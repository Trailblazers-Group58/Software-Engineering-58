// Utility Functions
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

function announceToScreenReader(message) {
  const announcement = document.getElementById("announcements")
  if (announcement) {
    announcement.textContent = message
    setTimeout(() => {
      announcement.textContent = ""
    }, 1000)
  }
}

function handleError(error, context) {
  console.error(`Error in ${context}:`, error)
  announceToScreenReader("An error occurred. Please try again.")
}

// Form Validation
function validateField(field) {
  const value = field.value.trim()
  const fieldName = field.name
  const errorElement = document.getElementById(`${field.id}-error`)

  let isValid = true
  let errorMessage = ""

  // Required field validation
  if (field.hasAttribute("required") && !value) {
    isValid = false
    errorMessage = `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`
  }

  // Specific field validations
  switch (fieldName) {
    case "email":
      if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        isValid = false
        errorMessage = "Please enter a valid email address"
      }
      break

    case "password":
      if (value && value.length < 6) {
        isValid = false
        errorMessage = "Password must be at least 6 characters long"
      }
      break
  }

  // Update field appearance and error message
  if (isValid) {
    field.classList.remove("invalid")
    if (errorElement) errorElement.textContent = ""
  } else {
    field.classList.add("invalid")
    if (errorElement) {
      errorElement.textContent = errorMessage
      announceToScreenReader(errorMessage)
    }
  }

  return isValid
}

function validateForm() {
  const form = document.getElementById("loginForm")
  const requiredFields = form.querySelectorAll("[required]")
  let isFormValid = true

  requiredFields.forEach((field) => {
    if (!validateField(field)) {
      isFormValid = false
    }
  })

  return isFormValid
}

// Password Toggle Functionality
function setupPasswordToggle() {
  const passwordInput = document.getElementById("password")
  const passwordToggle = document.querySelector(".password-toggle")

  if (!passwordInput || !passwordToggle) return

  passwordToggle.addEventListener("click", function () {
    const isPassword = passwordInput.type === "password"

    // Toggle input type
    passwordInput.type = isPassword ? "text" : "password"

    // Toggle icon
    const icon = this.querySelector("i")
    icon.className = isPassword ? "fas fa-eye-slash" : "fas fa-eye"

    // Update aria-label
    this.setAttribute("aria-label", isPassword ? "Hide password" : "Show password")

    // Announce to screen readers
    announceToScreenReader(isPassword ? "Password shown" : "Password hidden")

    // Keep focus on password input
    passwordInput.focus()
  })
}

// Login Form Submission
function setupLoginForm() {
  const form = document.getElementById("loginForm")
  const submitButton = document.querySelector(".continue-btn")

  if (!form || !submitButton) return

  form.addEventListener("submit", async (e) => {
    e.preventDefault()

    try {
      // Validate form
      if (!validateForm()) {
        announceToScreenReader("Please correct the errors in the form")
        return
      }

      // Show loading state
      submitButton.disabled = true
      submitButton.classList.add("loading")

      // Collect form data
      const formData = new FormData(form)
      const loginData = {
        email: formData.get("email"),
        password: formData.get("password"),
        rememberMe: formData.get("rememberMe") === "on",
        timestamp: new Date().toISOString(),
      }

      console.log("Login attempt:", { ...loginData, password: "[REDACTED]" })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simulate login success/failure
      const isSuccess = Math.random() > 0.3 // 70% success rate for demo

      if (isSuccess) {
        // Show success message
        showSuccessMessage("Login successful! Redirecting...")

        // Save login state if remember me is checked
        if (loginData.rememberMe) {
          localStorage.setItem("rememberedEmail", loginData.email)
        }

        // Clear saved form data
        clearSavedData()

        // Simulate redirect after delay
        setTimeout(() => {
          announceToScreenReader("Redirecting to dashboard")
          console.log("Redirecting to dashboard...")
          // window.location.href = "/dashboard"
        }, 1500)
      } else {
        // Show error message
        showErrorMessage("Invalid email or password. Please try again.")
      }

      // Reset button state
      submitButton.disabled = false
      submitButton.classList.remove("loading")
    } catch (error) {
      handleError(error, "login form submission")

      // Reset button state on error
      submitButton.disabled = false
      submitButton.classList.remove("loading")
    }
  })
}

function showSuccessMessage(message) {
  const successMessage = document.createElement("div")
  successMessage.className = "success-message"
  successMessage.innerHTML = `
    <i class="fas fa-check-circle" aria-hidden="true"></i>
    <div>
      <strong>${message}</strong>
    </div>
  `

  const form = document.getElementById("loginForm")
  form.parentNode.insertBefore(successMessage, form)

  announceToScreenReader(message)

  // Remove message after 3 seconds
  setTimeout(() => {
    if (successMessage.parentNode) {
      successMessage.parentNode.removeChild(successMessage)
    }
  }, 3000)
}

function showErrorMessage(message) {
  const errorMessage = document.createElement("div")
  errorMessage.className = "error-message"
  errorMessage.style.cssText = `
    background: #fef2f2;
    border: 1px solid #fecaca;
    color: #dc2626;
    padding: 1rem;
    border-radius: 0.375rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  `
  errorMessage.innerHTML = `
    <i class="fas fa-exclamation-circle" aria-hidden="true"></i>
    <div>
      <strong>${message}</strong>
    </div>
  `

  const form = document.getElementById("loginForm")
  form.parentNode.insertBefore(errorMessage, form)

  announceToScreenReader(message)

  // Remove message after 5 seconds
  setTimeout(() => {
    if (errorMessage.parentNode) {
      errorMessage.parentNode.removeChild(errorMessage)
    }
  }, 5000)
}

// Real-time Form Validation
function setupRealTimeValidation() {
  const formInputs = document.querySelectorAll(".form-input")

  formInputs.forEach((input) => {
    // Validate on blur (when user leaves field)
    input.addEventListener("blur", function () {
      validateField(this)
    })

    // Clear errors on input (when user starts typing)
    input.addEventListener("input", function () {
      if (this.classList.contains("invalid")) {
        const errorElement = document.getElementById(`${this.id}-error`)
        if (errorElement) {
          errorElement.textContent = ""
        }
        this.classList.remove("invalid")
      }
    })
  })
}

// Social Login Handlers
function setupSocialLogin() {
  const socialButtons = document.querySelectorAll(".social-btn")

  socialButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const platform = this.classList.contains("google-btn") ? "Google" : "Facebook"

      console.log(`${platform} login clicked`)
      announceToScreenReader(`Opening ${platform} login`)

      // Simulate social login
      this.disabled = true
      this.innerHTML = `<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Connecting to ${platform}...`

      setTimeout(() => {
        this.disabled = false
        this.innerHTML = this.classList.contains("google-btn")
          ? '<i class="fab fa-google" aria-hidden="true"></i><span>Continue with Google</span>'
          : '<i class="fab fa-facebook-f" aria-hidden="true"></i><span>Continue with Facebook</span>'

        showSuccessMessage(`${platform} login successful!`)
      }, 2000)
    })
  })
}

// Search Functionality
function setupSearch() {
  const searchInput = document.getElementById("searchInput")

  if (!searchInput) return

  const debouncedSearch = debounce((searchTerm) => {
    console.log(`Searching for: ${searchTerm}`)

    if (searchTerm.length > 2) {
      announceToScreenReader(`Searching for ${searchTerm}`)
    } else if (searchTerm.length === 0) {
      announceToScreenReader("Search cleared")
    }
  }, 300)

  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase().trim()
    debouncedSearch(searchTerm)
  })

  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault()
      const searchTerm = this.value.trim()
      if (searchTerm) {
        announceToScreenReader(`Searching for ${searchTerm}`)
        console.log(`Search submitted: ${searchTerm}`)
      }
    }
  })
}

// Keyboard Navigation
function setupKeyboardNavigation() {
  document.addEventListener("keydown", (e) => {
    try {
      // Keyboard shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "k":
            e.preventDefault()
            const searchInput = document.getElementById("searchInput")
            if (searchInput) {
              searchInput.focus()
              announceToScreenReader("Search focused")
            }
            break

          case "Enter":
            // Submit form with Ctrl+Enter
            if (e.target.tagName === "INPUT" && e.target.type !== "submit") {
              e.preventDefault()
              const form = document.getElementById("loginForm")
              if (form) {
                form.dispatchEvent(new Event("submit"))
              }
            }
            break
        }
      }

      // Enter key on social buttons
      if (e.key === "Enter" && e.target.classList.contains("social-btn")) {
        e.target.click()
      }
    } catch (error) {
      handleError(error, "keyboard navigation")
    }
  })
}

// Auto-save Form Data (localStorage)
function setupAutoSave() {
  const form = document.getElementById("loginForm")
  if (!form) return

  // Load remembered email
  const rememberedEmail = localStorage.getItem("rememberedEmail")
  if (rememberedEmail) {
    const emailInput = document.getElementById("email")
    const rememberCheckbox = document.getElementById("rememberMe")

    if (emailInput) emailInput.value = rememberedEmail
    if (rememberCheckbox) rememberCheckbox.checked = true
  }

  // Load saved data
  const savedData = localStorage.getItem("loginFormData")
  if (savedData) {
    try {
      const data = JSON.parse(savedData)
      Object.keys(data).forEach((key) => {
        const field = form.querySelector(`[name="${key}"]`)
        if (field && field.type !== "password") {
          // Don't save passwords
          if (field.type === "checkbox") {
            field.checked = data[key]
          } else {
            field.value = data[key]
          }
        }
      })
    } catch (error) {
      console.warn("Failed to load saved form data:", error)
    }
  }

  // Save data on input (excluding password)
  const debouncedSave = debounce(() => {
    try {
      const formData = new FormData(form)
      const data = Object.fromEntries(formData.entries())
      delete data.password // Don't save password
      localStorage.setItem("loginFormData", JSON.stringify(data))
    } catch (error) {
      console.warn("Failed to save form data:", error)
    }
  }, 1000)

  form.addEventListener("input", debouncedSave)
  form.addEventListener("change", debouncedSave)
}

// Clear saved data on successful login
function clearSavedData() {
  localStorage.removeItem("loginFormData")
}

// Link Handlers
function setupLinkHandlers() {
  // Forgot password link
  const forgotPasswordLink = document.querySelector(".forgot-password-link")
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener("click", (e) => {
      e.preventDefault()
      announceToScreenReader("Opening forgot password form")
      console.log("Forgot password clicked")
      // Here you would typically show a forgot password modal or redirect
    })
  }

  // Create account link
  const createAccountLink = document.querySelector(".create-account-link")
  if (createAccountLink) {
    createAccountLink.addEventListener("click", (e) => {
      e.preventDefault()
      announceToScreenReader("Opening registration form")
      console.log("Create account clicked")
      // Here you would typically redirect to registration page
    })
  }
}

// Performance Monitoring
function setupPerformanceMonitoring() {
  window.addEventListener("load", () => {
    if (window.performance && window.performance.timing) {
      const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart
      console.log(`Login page load time: ${loadTime}ms`)

      if (loadTime > 3000) {
        console.warn("Login page load time is slow. Consider optimization.")
      }
    }
  })
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  try {
    // Initialize all components
    setupPasswordToggle()
    setupLoginForm()
    setupRealTimeValidation()
    setupSocialLogin()
    setupSearch()
    setupKeyboardNavigation()
    setupAutoSave()
    setupLinkHandlers()
    setupPerformanceMonitoring()

    // Focus on email input for better UX
    const emailInput = document.getElementById("email")
    if (emailInput && !emailInput.value) {
      setTimeout(() => emailInput.focus(), 100)
    }

    // Announce page load
    announceToScreenReader("Login page loaded successfully")

    console.log("Grace Clothing Login Page initialized successfully!")
  } catch (error) {
    handleError(error, "initialization")
  }
})

// Handle page visibility changes
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    console.log("Login page is now visible")
  }
})

// Export functions for testing (if needed)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    validateField,
    validateForm,
    showSuccessMessage,
    showErrorMessage,
    clearSavedData,
  }
}
