// Utility Functions
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

function announceToScreenReader(message) {
  const announcement = document.getElementById("announcements")
  if (announcement) {
    announcement.textContent = message
    setTimeout(() => {
      announcement.textContent = ""
    }, 1000)
  }
}

function handleError(error, context) {
  console.error(`Error in ${context}:`, error)
  announceToScreenReader("An error occurred. Please try again.")
}

// Form Validation
function validateField(field) {
  const value = field.value.trim()
  const fieldName = field.name
  const errorElement = document.getElementById(`${field.id}-error`)

  let isValid = true
  let errorMessage = ""

  // Required field validation
  if (field.hasAttribute("required") && !value) {
    isValid = false
    errorMessage = `${fieldName.replace(/([A-Z])/g, " $1").toLowerCase()} is required`
  }

  // Specific field validations
  switch (fieldName) {
    case "fullName":
      if (value && value.length < 2) {
        isValid = false
        errorMessage = "Full name must be at least 2 characters long"
      }
      break

    case "emailAddress":
      if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        isValid = false
        errorMessage = "Please enter a valid email address"
      }
      break

    case "message":
      if (value && value.length < 10) {
        isValid = false
        errorMessage = "Message must be at least 10 characters long"
      }
      break
  }

  // Update field appearance and error message
  if (isValid) {
    field.classList.remove("invalid")
    if (errorElement) errorElement.textContent = ""
  } else {
    field.classList.add("invalid")
    if (errorElement) {
      errorElement.textContent = errorMessage
      announceToScreenReader(errorMessage)
    }
  }

  return isValid
}

function validateForm() {
  const form = document.getElementById("contactForm")
  const requiredFields = form.querySelectorAll("[required]")
  let isFormValid = true

  requiredFields.forEach((field) => {
    if (!validateField(field)) {
      isFormValid = false
    }
  })

  return isFormValid
}

// Contact Form Submission
function setupContactForm() {
  const form = document.getElementById("contactForm")
  const submitButton = document.querySelector(".send-message-btn")

  if (!form || !submitButton) return

  form.addEventListener("submit", async (e) => {
    e.preventDefault()

    try {
      // Validate form
      if (!validateForm()) {
        announceToScreenReader("Please correct the errors in the form")
        return
      }

      // Disable button and show loading state
      submitButton.disabled = true
      submitButton.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Sending...'

      // Collect form data
      const formData = new FormData(form)
      const contactData = {
        fullName: formData.get("fullName"),
        emailAddress: formData.get("emailAddress"),
        message: formData.get("message"),
        timestamp: new Date().toISOString(),
      }

      console.log("Contact form submitted:", contactData)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Show success message
      showSuccessMessage()

      // Reset form
      form.reset()

      // Reset button
      submitButton.disabled = false
      submitButton.innerHTML = '<i class="fas fa-paper-plane" aria-hidden="true"></i> Send Message'

      announceToScreenReader("Message sent successfully!")
    } catch (error) {
      handleError(error, "contact form submission")

      // Reset button on error
      submitButton.disabled = false
      submitButton.innerHTML = '<i class="fas fa-paper-plane" aria-hidden="true"></i> Send Message'
    }
  })
}

function showSuccessMessage() {
  const successMessage = document.createElement("div")
  successMessage.className = "success-message"
  successMessage.innerHTML = `
    <i class="fas fa-check-circle" aria-hidden="true"></i>
    <div>
      <strong>Message sent successfully!</strong>
      <p>We'll get back to you within 24 hours.</p>
    </div>
  `

  const form = document.getElementById("contactForm")
  form.parentNode.insertBefore(successMessage, form)

  // Remove message after 5 seconds
  setTimeout(() => {
    if (successMessage.parentNode) {
      successMessage.parentNode.removeChild(successMessage)
    }
  }, 5000)
}

// Real-time Form Validation
function setupRealTimeValidation() {
  const formInputs = document.querySelectorAll(".form-input, .form-textarea")

  formInputs.forEach((input) => {
    // Validate on blur (when user leaves field)
    input.addEventListener("blur", function () {
      validateField(this)
    })

    // Clear errors on input (when user starts typing)
    input.addEventListener("input", function () {
      if (this.classList.contains("invalid")) {
        const errorElement = document.getElementById(`${this.id}-error`)
        if (errorElement) {
          errorElement.textContent = ""
        }
        this.classList.remove("invalid")
      }
    })
  })
}

// Search Functionality
function setupSearch() {
  const searchInput = document.getElementById("searchInput")

  if (!searchInput) return

  const debouncedSearch = debounce((searchTerm) => {
    console.log(`Searching for: ${searchTerm}`)

    if (searchTerm.length > 2) {
      announceToScreenReader(`Searching for ${searchTerm}`)
    } else if (searchTerm.length === 0) {
      announceToScreenReader("Search cleared")
    }
  }, 300)

  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase().trim()
    debouncedSearch(searchTerm)
  })

  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault()
      const searchTerm = this.value.trim()
      if (searchTerm) {
        announceToScreenReader(`Searching for ${searchTerm}`)
        console.log(`Search submitted: ${searchTerm}`)
      }
    }
  })
}

// Smooth Scrolling for Anchor Links
function setupSmoothScrolling() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })

        // Announce navigation to screen readers
        const targetText = target.textContent || target.getAttribute("aria-label") || "section"
        announceToScreenReader(`Navigated to ${targetText}`)
      }
    })
  })
}

// Keyboard Navigation
function setupKeyboardNavigation() {
  document.addEventListener("keydown", (e) => {
    try {
      // Keyboard shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "k":
            e.preventDefault()
            const searchInput = document.getElementById("searchInput")
            if (searchInput) {
              searchInput.focus()
              announceToScreenReader("Search focused")
            }
            break

          case "Enter":
            // Submit form with Ctrl+Enter
            if (e.target.tagName === "TEXTAREA") {
              e.preventDefault()
              const form = document.getElementById("contactForm")
              if (form) {
                form.dispatchEvent(new Event("submit"))
              }
            }
            break
        }
      }
    } catch (error) {
      handleError(error, "keyboard navigation")
    }
  })
}

// Intersection Observer for Animations
function setupScrollAnimations() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1"
        entry.target.style.transform = "translateY(0)"
      }
    })
  }, observerOptions)

  // Observe content blocks
  const contentBlocks = document.querySelectorAll(".content-block")
  contentBlocks.forEach((block) => {
    block.style.opacity = "0"
    block.style.transform = "translateY(30px)"
    block.style.transition = "opacity 0.6s ease-out, transform 0.6s ease-out"
    observer.observe(block)
  })

  // Observe contact section
  const contactSection = document.querySelector(".contact-section")
  if (contactSection) {
    contactSection.style.opacity = "0"
    contactSection.style.transform = "translateY(30px)"
    contactSection.style.transition = "opacity 0.8s ease-out, transform 0.8s ease-out"
    observer.observe(contactSection)
  }
}

// Auto-save Form Data (localStorage)
function setupAutoSave() {
  const form = document.getElementById("contactForm")
  if (!form) return

  // Load saved data
  const savedData = localStorage.getItem("contactFormData")
  if (savedData) {
    try {
      const data = JSON.parse(savedData)
      Object.keys(data).forEach((key) => {
        const field = form.querySelector(`[name="${key}"]`)
        if (field) {
          field.value = data[key]
        }
      })
    } catch (error) {
      console.warn("Failed to load saved form data:", error)
    }
  }

  // Save data on input
  const debouncedSave = debounce(() => {
    try {
      const formData = new FormData(form)
      const data = Object.fromEntries(formData.entries())
      localStorage.setItem("contactFormData", JSON.stringify(data))
    } catch (error) {
      console.warn("Failed to save form data:", error)
    }
  }, 1000)

  form.addEventListener("input", debouncedSave)
}

// Clear saved data on successful submission
function clearSavedData() {
  localStorage.removeItem("contactFormData")
}

// Social Media Link Tracking
function setupSocialTracking() {
  const socialLinks = document.querySelectorAll(".social-icon, .footer-social-icon")

  socialLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      // Don't prevent default, but log the interaction
      const platform = this.querySelector("i").className.includes("facebook")
        ? "Facebook"
        : this.querySelector("i").className.includes("instagram")
          ? "Instagram"
          : this.querySelector("i").className.includes("twitter")
            ? "Twitter"
            : this.querySelector("i").className.includes("linkedin")
              ? "LinkedIn"
              : this.querySelector("i").className.includes("snapchat")
                ? "Snapchat"
                : "Unknown"

      console.log(`Social media click: ${platform}`)
      announceToScreenReader(`Opening ${platform} in new tab`)
    })
  })
}

// Performance Monitoring
function setupPerformanceMonitoring() {
  window.addEventListener("load", () => {
    if (window.performance && window.performance.timing) {
      const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart
      console.log(`About page load time: ${loadTime}ms`)

      if (loadTime > 3000) {
        console.warn("About page load time is slow. Consider optimization.")
      }
    }
  })
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  try {
    // Initialize all components
    setupContactForm()
    setupRealTimeValidation()
    setupSearch()
    setupSmoothScrolling()
    setupKeyboardNavigation()
    setupScrollAnimations()
    setupAutoSave()
    setupSocialTracking()
    setupPerformanceMonitoring()

    // Announce page load
    announceToScreenReader("About page loaded successfully")

    console.log("Grace Clothing About Page initialized successfully!")
  } catch (error) {
    handleError(error, "initialization")
  }
})

// Handle page visibility changes
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    console.log("About page is now visible")
  }
})

// Export functions for testing (if needed)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    validateField,
    validateForm,
    showSuccessMessage,
    clearSavedData,
  }
}
