// Utility Functions
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

function announceToScreenReader(message) {
  const announcement = document.getElementById("announcements")
  if (announcement) {
    announcement.textContent = message
    setTimeout(() => {
      announcement.textContent = ""
    }, 1000)
  }
}

function handleError(error, context) {
  console.error(`Error in ${context}:`, error)
  announceToScreenReader("An error occurred. Please try again.")
}

// Password Strength Checker
function checkPasswordStrength(password) {
  let score = 0
  const feedback = []

  // Length check
  if (password.length >= 8) score += 1
  else feedback.push("at least 8 characters")

  // Uppercase check
  if (/[A-Z]/.test(password)) score += 1
  else feedback.push("uppercase letter")

  // Lowercase check
  if (/[a-z]/.test(password)) score += 1
  else feedback.push("lowercase letter")

  // Number check
  if (/\d/.test(password)) score += 1
  else feedback.push("number")

  // Special character check
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score += 1
  else feedback.push("special character")

  const strength = score <= 1 ? "weak" : score <= 2 ? "fair" : score <= 3 ? "good" : "strong"
  const strengthText = score <= 1 ? "Weak" : score <= 2 ? "Fair" : score <= 3 ? "Good" : "Strong"

  return {
    score,
    strength,
    strengthText,
    feedback,
    isValid: score >= 3,
  }
}

function updatePasswordStrength(password) {
  const strengthIndicator = document.getElementById("passwordStrength")
  const strengthFill = document.getElementById("strengthFill")
  const strengthText = document.getElementById("strengthText")

  if (!password) {
    strengthFill.className = "strength-fill"
    strengthText.textContent = "Password strength"
    strengthText.className = "strength-text"
    return
  }

  const result = checkPasswordStrength(password)

  strengthFill.className = `strength-fill ${result.strength}`
  strengthText.textContent = `${result.strengthText} password`
  strengthText.className = `strength-text ${result.strength}`

  if (result.feedback.length > 0 && password.length > 0) {
    const missing = result.feedback.slice(0, 2).join(", ")
    strengthText.textContent += ` - Add ${missing}`
  }
}

// Form Validation
function validateField(field) {
  const value = field.value.trim()
  const fieldName = field.name
  const errorElement = document.getElementById(`${field.id}-error`)

  let isValid = true
  let errorMessage = ""

  // Required field validation
  if (field.hasAttribute("required") && !value) {
    isValid = false
    errorMessage = `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`
  }

  // Specific field validations
  switch (fieldName) {
    case "email":
      if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        isValid = false
        errorMessage = "Please enter a valid email address"
      }
      break

    case "password":
      if (value) {
        const strength = checkPasswordStrength(value)
        if (!strength.isValid) {
          isValid = false
          errorMessage = "Password must be at least 8 characters with uppercase, lowercase, and number"
        }
      }
      break

    case "confirmPassword":
      const passwordField = document.getElementById("password")
      if (value && value !== passwordField.value) {
        isValid = false
        errorMessage = "Passwords do not match"
      }
      break

    case "agreeTerms":
      if (!field.checked) {
        isValid = false
        errorMessage = "You must agree to the Terms of Service and Privacy Policy"
      }
      break
  }

  // Update field appearance and error message
  if (isValid) {
    field.classList.remove("invalid")
    if (errorElement) errorElement.textContent = ""
  } else {
    field.classList.add("invalid")
    if (errorElement) {
      errorElement.textContent = errorMessage
      announceToScreenReader(errorMessage)
    }
  }

  return isValid
}

function validateForm() {
  const form = document.getElementById("registerForm")
  const requiredFields = form.querySelectorAll("[required]")
  let isFormValid = true

  requiredFields.forEach((field) => {
    if (!validateField(field)) {
      isFormValid = false
    }
  })

  return isFormValid
}

// Password Toggle Functionality
function setupPasswordToggle() {
  const passwordToggles = document.querySelectorAll(".password-toggle")

  passwordToggles.forEach((toggle) => {
    toggle.addEventListener("click", function () {
      const passwordInput = this.parentNode.querySelector(".password-input")
      const isPassword = passwordInput.type === "password"

      // Toggle input type
      passwordInput.type = isPassword ? "text" : "password"

      // Toggle icon
      const icon = this.querySelector("i")
      icon.className = isPassword ? "fas fa-eye-slash" : "fas fa-eye"

      // Update aria-label
      this.setAttribute("aria-label", isPassword ? "Hide password" : "Show password")

      // Announce to screen readers
      announceToScreenReader(isPassword ? "Password shown" : "Password hidden")

      // Keep focus on password input
      passwordInput.focus()
    })
  })
}

// Registration Form Submission
function setupRegistrationForm() {
  const form = document.getElementById("registerForm")
  const submitButton = document.querySelector(".continue-btn")

  if (!form || !submitButton) return

  form.addEventListener("submit", async (e) => {
    e.preventDefault()

    try {
      // Validate form
      if (!validateForm()) {
        announceToScreenReader("Please correct the errors in the form")
        return
      }

      // Show loading state
      submitButton.disabled = true
      submitButton.classList.add("loading")

      // Collect form data
      const formData = new FormData(form)
      const registrationData = {
        email: formData.get("email"),
        password: formData.get("password"),
        confirmPassword: formData.get("confirmPassword"),
        agreeTerms: formData.get("agreeTerms") === "on",
        newsletter: formData.get("newsletter") === "on",
        timestamp: new Date().toISOString(),
      }

      console.log("Registration attempt:", {
        ...registrationData,
        password: "[REDACTED]",
        confirmPassword: "[REDACTED]",
      })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2500))

      // Simulate registration success/failure
      const isSuccess = Math.random() > 0.2 // 80% success rate for demo

      if (isSuccess) {
        // Show success message
        showSuccessMessage("Account created successfully! Please check your email to verify your account.")

        // Clear saved form data
        clearSavedData()

        // Simulate redirect after delay
        setTimeout(() => {
          announceToScreenReader("Redirecting to login page")
          console.log("Redirecting to login page...")
          // window.location.href = "/login"
        }, 2000)
      } else {
        // Show error message
        showErrorMessage("Registration failed. This email may already be registered.")
      }

      // Reset button state
      submitButton.disabled = false
      submitButton.classList.remove("loading")
    } catch (error) {
      handleError(error, "registration form submission")

      // Reset button state on error
      submitButton.disabled = false
      submitButton.classList.remove("loading")
    }
  })
}

function showSuccessMessage(message) {
  const successMessage = document.createElement("div")
  successMessage.className = "success-message"
  successMessage.innerHTML = `
    <i class="fas fa-check-circle" aria-hidden="true"></i>
    <div>
      <strong>${message}</strong>
    </div>
  `

  const form = document.getElementById("registerForm")
  form.parentNode.insertBefore(successMessage, form)

  announceToScreenReader(message)

  // Remove message after 4 seconds
  setTimeout(() => {
    if (successMessage.parentNode) {
      successMessage.parentNode.removeChild(successMessage)
    }
  }, 4000)
}

function showErrorMessage(message) {
  const errorMessage = document.createElement("div")
  errorMessage.className = "error-message"
  errorMessage.style.cssText = `
    background: #fef2f2;
    border: 1px solid #fecaca;
    color: #dc2626;
    padding: 1rem;
    border-radius: 0.375rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  `
  errorMessage.innerHTML = `
    <i class="fas fa-exclamation-circle" aria-hidden="true"></i>
    <div>
      <strong>${message}</strong>
    </div>
  `

  const form = document.getElementById("registerForm")
  form.parentNode.insertBefore(errorMessage, form)

  announceToScreenReader(message)

  // Remove message after 5 seconds
  setTimeout(() => {
    if (errorMessage.parentNode) {
      errorMessage.parentNode.removeChild(errorMessage)
    }
  }, 5000)
}

// Real-time Form Validation
function setupRealTimeValidation() {
  const formInputs = document.querySelectorAll(".form-input")
  const passwordInput = document.getElementById("password")
  const confirmPasswordInput = document.getElementById("confirmPassword")

  formInputs.forEach((input) => {
    // Validate on blur (when user leaves field)
    input.addEventListener("blur", function () {
      validateField(this)
    })

    // Clear errors on input (when user starts typing)
    input.addEventListener("input", function () {
      if (this.classList.contains("invalid")) {
        const errorElement = document.getElementById(`${this.id}-error`)
        if (errorElement) {
          errorElement.textContent = ""
        }
        this.classList.remove("invalid")
      }
    })
  })

  // Password strength checking
  if (passwordInput) {
    passwordInput.addEventListener("input", function () {
      updatePasswordStrength(this.value)

      // Also validate confirm password if it has a value
      if (confirmPasswordInput && confirmPasswordInput.value) {
        validateField(confirmPasswordInput)
      }
    })
  }

  // Confirm password validation
  if (confirmPasswordInput) {
    confirmPasswordInput.addEventListener("input", function () {
      if (this.value) {
        validateField(this)
      }
    })
  }
}

// Social Registration Handlers
function setupSocialRegistration() {
  const socialButtons = document.querySelectorAll(".social-btn")

  socialButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const platform = this.classList.contains("google-btn") ? "Google" : "Facebook"

      console.log(`${platform} registration clicked`)
      announceToScreenReader(`Opening ${platform} registration`)

      // Simulate social registration
      this.disabled = true
      this.innerHTML = `<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Connecting to ${platform}...`

      setTimeout(() => {
        this.disabled = false
        this.innerHTML = this.classList.contains("google-btn")
          ? '<i class="fab fa-google" aria-hidden="true"></i><span>Register with Google</span>'
          : '<i class="fab fa-facebook-f" aria-hidden="true"></i><span>Register with Facebook</span>'

        showSuccessMessage(`${platform} registration successful!`)
      }, 2000)
    })
  })
}

// Search Functionality
function setupSearch() {
  const searchInput = document.getElementById("searchInput")

  if (!searchInput) return

  const debouncedSearch = debounce((searchTerm) => {
    console.log(`Searching for: ${searchTerm}`)

    if (searchTerm.length > 2) {
      announceToScreenReader(`Searching for ${searchTerm}`)
    } else if (searchTerm.length === 0) {
      announceToScreenReader("Search cleared")
    }
  }, 300)

  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase().trim()
    debouncedSearch(searchTerm)
  })

  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault()
      const searchTerm = this.value.trim()
      if (searchTerm) {
        announceToScreenReader(`Searching for ${searchTerm}`)
        console.log(`Search submitted: ${searchTerm}`)
      }
    }
  })
}

// Keyboard Navigation
function setupKeyboardNavigation() {
  document.addEventListener("keydown", (e) => {
    try {
      // Keyboard shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "k":
            e.preventDefault()
            const searchInput = document.getElementById("searchInput")
            if (searchInput) {
              searchInput.focus()
              announceToScreenReader("Search focused")
            }
            break

          case "Enter":
            // Submit form with Ctrl+Enter
            if (e.target.tagName === "INPUT" && e.target.type !== "submit") {
              e.preventDefault()
              const form = document.getElementById("registerForm")
              if (form) {
                form.dispatchEvent(new Event("submit"))
              }
            }
            break
        }
      }

      // Enter key on social buttons
      if (e.key === "Enter" && e.target.classList.contains("social-btn")) {
        e.target.click()
      }
    } catch (error) {
      handleError(error, "keyboard navigation")
    }
  })
}

// Auto-save Form Data (localStorage)
function setupAutoSave() {
  const form = document.getElementById("registerForm")
  if (!form) return

  // Load saved data
  const savedData = localStorage.getItem("registerFormData")
  if (savedData) {
    try {
      const data = JSON.parse(savedData)
      Object.keys(data).forEach((key) => {
        const field = form.querySelector(`[name="${key}"]`)
        if (field && !key.includes("password")) {
          // Don't save passwords
          if (field.type === "checkbox") {
            field.checked = data[key]
          } else {
            field.value = data[key]
          }
        }
      })
    } catch (error) {
      console.warn("Failed to load saved form data:", error)
    }
  }

  // Save data on input (excluding passwords)
  const debouncedSave = debounce(() => {
    try {
      const formData = new FormData(form)
      const data = Object.fromEntries(formData.entries())
      delete data.password // Don't save passwords
      delete data.confirmPassword
      localStorage.setItem("registerFormData", JSON.stringify(data))
    } catch (error) {
      console.warn("Failed to save form data:", error)
    }
  }, 1000)

  form.addEventListener("input", debouncedSave)
  form.addEventListener("change", debouncedSave)
}

// Clear saved data on successful registration
function clearSavedData() {
  localStorage.removeItem("registerFormData")
}

// Link Handlers
function setupLinkHandlers() {
  // Terms of Service link
  const termsLink = document.querySelector(".terms-link")
  if (termsLink) {
    termsLink.addEventListener("click", (e) => {
      e.preventDefault()
      announceToScreenReader("Opening Terms of Service")
      console.log("Terms of Service clicked")
      // Here you would typically show a modal or redirect
    })
  }

  // Privacy Policy link
  const privacyLink = document.querySelector(".privacy-link")
  if (privacyLink) {
    privacyLink.addEventListener("click", (e) => {
      e.preventDefault()
      announceToScreenReader("Opening Privacy Policy")
      console.log("Privacy Policy clicked")
      // Here you would typically show a modal or redirect
    })
  }

  // Login link
  const loginLink = document.querySelector(".login-link")
  if (loginLink) {
    loginLink.addEventListener("click", (e) => {
      e.preventDefault()
      announceToScreenReader("Opening login form")
      console.log("Login clicked")
      // Here you would typically redirect to login page
    })
  }
}

// Performance Monitoring
function setupPerformanceMonitoring() {
  window.addEventListener("load", () => {
    if (window.performance && window.performance.timing) {
      const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart
      console.log(`Registration page load time: ${loadTime}ms`)

      if (loadTime > 3000) {
        console.warn("Registration page load time is slow. Consider optimization.")
      }
    }
  })
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  try {
    // Initialize all components
    setupPasswordToggle()
    setupRegistrationForm()
    setupRealTimeValidation()
    setupSocialRegistration()
    setupSearch()
    setupKeyboardNavigation()
    setupAutoSave()
    setupLinkHandlers()
    setupPerformanceMonitoring()

    // Focus on email input for better UX
    const emailInput = document.getElementById("email")
    if (emailInput && !emailInput.value) {
      setTimeout(() => emailInput.focus(), 100)
    }

    // Announce page load
    announceToScreenReader("Registration page loaded successfully")

    console.log("Grace Clothing Registration Page initialized successfully!")
  } catch (error) {
    handleError(error, "initialization")
  }
})

// Handle page visibility changes
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    console.log("Registration page is now visible")
  }
})

// Export functions for testing (if needed)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    validateField,
    validateForm,
    checkPasswordStrength,
    updatePasswordStrength,
    showSuccessMessage,
    showErrorMessage,
    clearSavedData,
  }
}
