// Product data
const products = [
    {
        id: 1,
        name: "Kids/Toddlers shoe",
        category: "Kids shoes",
        price: "GHC120",
        originalPrice: "GHC180",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1514989940723-e8e51635b782?w=300&h=300&fit=crop",
        alt: "Black and white kids sneakers with laces"
    },
    {
        id: 2,
        name: "4pack Solid Seamless Pants",
        category: "Underwear",
        price: "GHC60",
        originalPrice: "GHC90",
        rating: 4.9,
        reviews: 88,
        image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=300&h=300&fit=crop",
        alt: "Pack of seamless underwear in various colors"
    },
    {
        id: 3,
        name: "Sleek Ladies Hand Bag",
        category: "Accessories",
        price: "GHC80",
        originalPrice: "GHC120",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
        alt: "Elegant gray leather handbag with handles"
    },
    {
        id: 4,
        name: "Ladies office wear",
        category: "Women's fashion",
        price: "GHC150",
        originalPrice: "GHC200",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=300&h=300&fit=crop",
        alt: "Professional black and white checkered dress"
    },
    {
        id: 5,
        name: "Green Silk Slip Dress",
        category: "Women's fashion",
        price: "GHC95",
        originalPrice: "GHC140",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=300&h=300&fit=crop",
        alt: "Elegant green silk slip dress on hanger"
    },
    {
        id: 6,
        name: "Short Sleeve Top",
        category: "Men's fashion",
        price: "GHC350",
        originalPrice: "GHC400",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
        alt: "Black and white striped short sleeve shirt"
    },
    {
        id: 7,
        name: "Calvin Klein Boxers",
        category: "Underwear",
        price: "GHC100",
        originalPrice: "GHC140",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=300&h=300&fit=crop",
        alt: "Calvin Klein branded boxer shorts in black and gray"
    },
    {
        id: 8,
        name: "Fashionable Hand Bags",
        category: "Accessories",
        price: "GHC80.99",
        originalPrice: "GHC120",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
        alt: "Stylish brown and teal color block handbag"
    },
    {
        id: 9,
        name: "Kids School bags",
        category: "Accessories",
        price: "GHC75",
        originalPrice: "GHC95",
        rating: 4.9,
        reviews: 98,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
        alt: "Colorful kids school backpack with multiple compartments"
    }
];

// State management
let currentProducts = [...products];
let wishlistItems = new Set();
let currentPage = 1;
const itemsPerPage = 9;

// Generate star rating HTML with accessibility
function generateStars(rating, productName) {
    const fullStars = Math.floor(rating);
    let starsHTML = '';
    
    for (let i = 0; i < 5; i++) {
        if (i < fullStars) {
            starsHTML += '<i class="fas fa-star star" aria-hidden="true"></i>';
        } else {
            starsHTML += '<i class="far fa-star star" aria-hidden="true"></i>';
        }
    }
    
    return `<div class="stars" role="img" aria-label="${rating} out of 5 stars for ${productName}">${starsHTML}</div>`;
}

// Create product card HTML with accessibility
function createProductCard(product) {
    const isWishlisted = wishlistItems.has(product.id);
    const wishlistClass = isWishlisted ? 'active' : '';
    const wishlistIcon = isWishlisted ? 'fas' : 'far';
    const wishlistLabel = isWishlisted ? 'Remove from wishlist' : 'Add to wishlist';

    return `
        <article class="product-card" role="article" aria-labelledby="product-${product.id}-name">
            <div class="product-image">
                <img src="${product.image}" alt="${product.alt}" loading="lazy">
                <button 
                    class="wishlist-btn ${wishlistClass}" 
                    onclick="toggleWishlist(${product.id})"
                    aria-label="${wishlistLabel}: ${product.name}"
                    data-product-id="${product.id}"
                >
                    <i class="${wishlistIcon} fa-heart" aria-hidden="true"></i>
                </button>
            </div>
            <div class="product-info">
                <h3 class="product-name" id="product-${product.id}-name">${product.name}</h3>
                <p class="product-category">${product.category}</p>
                <div class="price-container">
                    <span class="price" aria-label="Current price">${product.price}</span>
                    <span class="original-price" aria-label="Original price">${product.originalPrice}</span>
                </div>
                <div class="rating">
                    ${generateStars(product.rating, product.name)}
                    <span class="rating-text" aria-label="${product.reviews} reviews">${product.rating} (${product.reviews})</span>
                </div>
            </div>
        </article>
    `;
}

// Render products with loading and empty states
function renderProducts(productsToRender = currentProducts) {
    const productsGrid = document.getElementById('productsGrid');
    
    if (productsToRender.length === 0) {
        productsGrid.innerHTML = `
            <div class="empty-state" role="status" aria-live="polite">
                <h3>No products found</h3>
                <p>Try adjusting your filters or search terms.</p>
            </div>
        `;
        announceToScreenReader(`No products found. Try adjusting your filters.`);
        return;
    }

    // Show loading state briefly for better UX
    productsGrid.innerHTML = '<div class="loading" role="status" aria-live="polite">Loading products...</div>';
    
    setTimeout(() => {
        productsGrid.innerHTML = productsToRender.map(product => createProductCard(product)).join('');
        announceToScreenReader(`${productsToRender.length} products displayed`);
    }, 100);
}

// Toggle wishlist with accessibility feedback
function toggleWishlist(productId) {
    const product = products.find(p => p.id === productId);
    const button = document.querySelector(`[data-product-id="${productId}"]`);
    const icon = button.querySelector('i');
    
    if (wishlistItems.has(productId)) {
        wishlistItems.delete(productId);
        icon.classList.remove('fas');
        icon.classList.add('far');
        button.classList.remove('active');
        button.setAttribute('aria-label', `Add to wishlist: ${product.name}`);
        announceToScreenReader(`${product.name} removed from wishlist`);
    } else {
        wishlistItems.add(productId);
        icon.classList.remove('far');
        icon.classList.add('fas');
        button.classList.add('active');
        button.setAttribute('aria-label', `Remove from wishlist: ${product.name}`);
        announceToScreenReader(`${product.name} added to wishlist`);
    }
}

// Filter functionality with accessibility
function setupFilters() {
    // Category filters
    const categoryCheckboxes = document.querySelectorAll('input[name="category"]');
    categoryCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            filterProducts();
            const action = checkbox.checked ? 'applied' : 'removed';
            const categoryName = checkbox.parentElement.textContent.trim();
            announceToScreenReader(`${categoryName} filter ${action}`);
        });
    });
    
    // Sort functionality
    const sortRadios = document.querySelectorAll('input[name="sort"]');
    sortRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            filterProducts();
            const sortName = radio.parentElement.textContent.trim();
            announceToScreenReader(`Products sorted by ${sortName}`);
        });
    });
    
    // Price range
    const priceRange = document.getElementById('priceRange');
    priceRange.addEventListener('input', debounce(() => {
        filterProducts();
        const maxPrice = priceRange.value;
        document.getElementById('maxPriceDisplay').textContent = `GHC ${maxPrice}`;
        priceRange.setAttribute('aria-valuetext', `GHC ${maxPrice}`);
        announceToScreenReader(`Maximum price set to GHC ${maxPrice}`);
    }, 300));
}

// Debounce function for performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Filter products based on selected filters
function filterProducts() {
    let filteredProducts = [...products];
    
    // Category filter
    const selectedCategories = Array.from(document.querySelectorAll('input[name="category"]:checked'))
        .map(cb => cb.value);
    
    if (selectedCategories.length > 0) {
        filteredProducts = filteredProducts.filter(product => {
            const categoryMap = {
                'mens': "Men's fashion",
                'womens': "Women's fashion",
                'kids': "Kids shoes",
                'accessories': "Accessories",
                'underwear': "Underwear"
            };
            
            return selectedCategories.some(cat => 
                product.category === categoryMap[cat]
            );
        });
    }
    
    // Price filter
    const maxPrice = parseInt(document.getElementById('priceRange').value);
    filteredProducts = filteredProducts.filter(product => {
        const price = parseFloat(product.price.replace('GHC', '').replace('.99', ''));
        return price <= maxPrice;
    });
    
    // Sort
    const selectedSort = document.querySelector('input[name="sort"]:checked').value;
    
    switch (selectedSort) {
        case 'rating':
            filteredProducts.sort((a, b) => b.rating - a.rating);
            break;
        case 'newest':
            filteredProducts.reverse();
            break;
        case 'price-low':
            filteredProducts.sort((a, b) => {
                const priceA = parseFloat(a.price.replace('GHC', '').replace('.99', ''));
                const priceB = parseFloat(b.price.replace('GHC', '').replace('.99', ''));
                return priceA - priceB;
            });
            break;
        case 'price-high':
            filteredProducts.sort((a, b) => {
                const priceA = parseFloat(a.price.replace('GHC', '').replace('.99', ''));
                const priceB = parseFloat(b.price.replace('GHC', '').replace('.99', ''));
                return priceB - priceA;
            });
            break;
        default: // popular
            // Keep original order
            break;
    }
    
    currentProducts = filteredProducts;
    currentPage = 1;
    renderProducts(filteredProducts);
    updatePaginationState();
}

// Pagination functionality with accessibility
function setupPagination() {
    const pageButtons = document.querySelectorAll('.page-btn');
    
    pageButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (this.id === 'prevBtn') {
                if (currentPage > 1) {
                    currentPage--;
                    updatePaginationState();
                    announceToScreenReader(`Page ${currentPage}`);
                }
                return;
            }
            
            if (this.id === 'nextBtn') {
                const totalPages = Math.ceil(currentProducts.length / itemsPerPage);
                if (currentPage < totalPages) {
                    currentPage++;
                    updatePaginationState();
                    announceToScreenReader(`Page ${currentPage}`);
                }
                return;
            }
            
            // Handle numbered page buttons
            const pageNum = parseInt(this.textContent);
            if (pageNum && pageNum !== currentPage) {
                currentPage = pageNum;
                updatePaginationState();
                announceToScreenReader(`Page ${currentPage}`);
            }
        });
    });
}

// Update pagination state and buttons
function updatePaginationState() {
    const pageButtons = document.querySelectorAll('.page-btn:not(#prevBtn):not(#nextBtn)');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const totalPages = Math.ceil(currentProducts.length / itemsPerPage);
    
    // Update page buttons
    pageButtons.forEach((btn, index) => {
        const pageNum = index + 1;
        btn.classList.toggle('active', pageNum === currentPage);
        btn.setAttribute('aria-current', pageNum === currentPage ? 'page' : 'false');
        btn.setAttribute('aria-label', 
            pageNum === currentPage ? `Page ${pageNum}, current page` : `Go to page ${pageNum}`
        );
    });
    
    // Update prev/next buttons
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
    
    prevBtn.setAttribute('aria-disabled', currentPage === 1);
    nextBtn.setAttribute('aria-disabled', currentPage === totalPages);
    
    // Scroll to top of products
    document.getElementById('productsGrid').scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
    });
}

// Search functionality with accessibility
function setupSearch() {
    const searchInput = document.getElementById('searchInput');
    
    searchInput.addEventListener('input', debounce(function() {
        const searchTerm = this.value.toLowerCase().trim();
        
        if (searchTerm === '') {
            currentProducts = [...products];
        } else {
            currentProducts = products.filter(product =>
                product.name.toLowerCase().includes(searchTerm) ||
                product.category.toLowerCase().includes(searchTerm)
            );
        }
        
        currentPage = 1;
        renderProducts(currentProducts);
        updatePaginationState();
        
        // Announce results to screen readers
        const resultsCount = currentProducts.length;
        const announcement = searchTerm === '' 
            ? 'Showing all products' 
            : `${resultsCount} products found for "${searchTerm}"`;
        announceToScreenReader(announcement);
    }, 300));
    
    // Handle search form submission
    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            this.blur(); // Remove focus to trigger any pending debounced search
        }
    });
}

// Price range display update with accessibility
function setupPriceRange() {
    const priceRange = document.getElementById('priceRange');
    const maxPriceLabel = document.getElementById('maxPriceDisplay');
    
    priceRange.addEventListener('input', function() {
        maxPriceLabel.textContent = `GHC ${this.value}`;
        this.setAttribute('aria-valuetext', `GHC ${this.value}`);
    });
}

// Screen reader announcements
function announceToScreenReader(message) {
    const announcement = document.getElementById('announcements');
    announcement.textContent = message;
    
    // Clear after announcement
    setTimeout(() => {
        announcement.textContent = '';
    }, 1000);
}

// Keyboard navigation enhancements
function setupKeyboardNavigation() {
    // Handle escape key to clear search
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const searchInput = document.getElementById('searchInput');
            if (searchInput === document.activeElement && searchInput.value) {
                searchInput.value = '';
                searchInput.dispatchEvent(new Event('input'));
                announceToScreenReader('Search cleared');
            }
        }
    });
    
    // Handle arrow keys in pagination
    const pagination = document.querySelector('.pagination');
    pagination.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
            e.preventDefault();
            const buttons = Array.from(this.querySelectorAll('.page-btn:not(:disabled)'));
            const currentIndex = buttons.indexOf(document.activeElement);
            
            if (currentIndex !== -1) {
                let nextIndex;
                if (e.key === 'ArrowLeft') {
                    nextIndex = Math.max(0, currentIndex - 1);
                } else {
                    nextIndex = Math.min(buttons.length - 1, currentIndex + 1);
                }
                buttons[nextIndex].focus();
            }
        }
    });
}

// Error handling
function handleError(error, context) {
    console.error(`Error in ${context}:`, error);
    announceToScreenReader(`An error occurred. Please try again.`);
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    try {
        renderProducts();
        setupFilters();
        setupPagination();
        setupSearch();
        setupPriceRange();
        setupKeyboardNavigation();
        updatePaginationState();
        
        // Set initial ARIA attributes
        const priceRange = document.getElementById('priceRange');
        priceRange.setAttribute('aria-valuetext', `GHC ${priceRange.value}`);
        
        console.log('Grace Clothing Shop loaded successfully!');
        announceToScreenReader('Grace Clothing Shop loaded. Use filters to refine your search.');
    } catch (error) {
        handleError(error, 'initialization');
    }
});

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
        // Refresh data if needed when page becomes visible
        console.log('Page is now visible');
    }
});

// Service worker registration for offline support (optional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed');
            });
    });
}

// Performance monitoring
window.addEventListener('load', function() {
    // Log performance metrics
    if (window.performance && window.performance.timing) {
        const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;
        console.log(`Page load time: ${loadTime}ms`);
    }
});